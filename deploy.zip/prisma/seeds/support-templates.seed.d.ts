export declare function seedSupportTemplates(createdBy: string): Promise<void>;
//# sourceMappingURL=support-templates.seed.d.ts.map